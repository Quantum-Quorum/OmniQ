import subprocess
import sys
import os
from pathlib import Path

class QuantumDebugger:
    def __init__(self, circuit=None):
        self.circuit = circuit
        self.debugger_path = self._find_debugger()
    
    def _find_debugger(self):
        """Find the debugger executable"""
        # Look in common locations
        possible_paths = [
            Path(__file__).parent.parent.parent / "omniq-debugger" / "build" / "omniq-debugger",
            Path(__file__).parent.parent.parent / "omniq-debugger" / "omniq-debugger",
            Path(__file__).parent.parent.parent / "build_debugger" / "omniq-debugger",
            Path.home() / ".local" / "bin" / "omniq-debugger",
            "/usr/local/bin/omniq-debugger"
        ]
        
        for path in possible_paths:
            if path.exists() and os.access(path, os.X_OK):
                return str(path)
        
        raise FileNotFoundError("OmniQ debugger not found. Please build it first.")
    
    def show(self, circuit=None, noise_model=None, view_mode=None):
        """Show the quantum debugger GUI (like df.head())"""
        if circuit is not None:
            self.circuit = circuit
        
        import tempfile
        import json
        
        # Create a temporary file for the circuit
        temp_file = tempfile.NamedTemporaryFile(suffix='.json', delete=False)
        temp_path = temp_file.name
        temp_file.close()
        
        data = {}
        if self.circuit:
            data = self.circuit.to_dict()
        
        if noise_model:
            data["noise_model"] = noise_model.to_dict()

        if view_mode:
            data["initial_view"] = view_mode
            
        with open(temp_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        try:
            # Pass the temp file path as an argument
            print(f"🐛 Launching debugger from: {self.debugger_path}")
            print(f"📂 Loading circuit file: {temp_path}")
            
            # Using Popen without redirecting output so the user can see errors
            subprocess.Popen([self.debugger_path, temp_path])
            
            print(f"🚀 OmniQ Quantum Debugger opened with circuit and noise model!")
            print("   • Use the GUI to inspect quantum states")
            print("   • Drag and drop gates to build circuits")
            print("   • Step through quantum operations")
        except Exception as e:
            print(f"❌ Failed to open debugger: {e}")
            print("💡 Try building the debugger first: cd omniq-debugger && ./build.sh")
    
    def debug(self, circuit=None, view_mode=None):
        """Alias for show() - debug the circuit"""
        return self.show(circuit, view_mode=view_mode)
    
    def inspect(self, circuit=None, view_mode=None):
        """Another alias for show()"""
        return self.show(circuit, view_mode=view_mode)
    
# Convenience function
def show_debugger(circuit=None, noise_model=None, view_mode=None):
    """Quick function to show debugger (like df.head())"""
    debugger = QuantumDebugger(circuit)
    return debugger.show(noise_model=noise_model, view_mode=view_mode)

# Add debugger methods to Circuit class
def add_debugger_to_circuit():
    """Add debugger methods to Circuit class"""
    try:
        from .circuit import Circuit
        
        def debug(self, view_mode=None):
            """Show debugger for this circuit"""
            debugger = QuantumDebugger(self)
            return debugger.show(view_mode=view_mode)
        
        def show(self, view_mode=None):
            """Show debugger for this circuit"""
            return self.debug(view_mode=view_mode)
        
        Circuit.debug = debug
        Circuit.show = show
        
    except ImportError:
        pass  # Circuit class might not be available yet 